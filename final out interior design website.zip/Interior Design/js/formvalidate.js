function validate() {
  var username = document.getElementById("name");
  var password = document.getElementById("LastName");

  if (username.value =="" ||password =="")
   {
    alert("no blank values allowed");
  } 
  else
  {
    true;
  }
}